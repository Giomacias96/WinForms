﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DynamicLayout
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            if(TextBox1.Text.Length > 0)
            {
                TextBox1.Text.ToLower().Trim();
                TextBox2.Text = TextBox1.Text.ToLower().Replace(' ', '.') + "@aptiv.com";
            }
            else
            {
                TextBox2.Text = "Ingrese un nombre valido.";
            }
            if(TextBox2.Text != null)
            {
                Button1.IsEnabled = false;
                //Button1.Click -= Button1_Click;
            }
            /*if (TextBox1.Text != null)
            {
                TextBox1.Text.ToLower().Trim();
                TextBox2.Text = TextBox1.Text.ToLower().Replace(' ', '.') + "@aptiv.com";
            }
            else if(TextBox1.Text == " ")
            {
                TextBox2.Text = "Ingrese un nombre valido";
            }
            if (TextBox2.Text != null)
            {
                Button1.IsEnabled = false;
                //Button1.Click -= Button1_Click;
            }*/
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            TextBox1.Text = null; 
            TextBox2.Text = null;
            Button1.IsEnabled = true;
        }

        private void TextBox2_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }
    }
}
